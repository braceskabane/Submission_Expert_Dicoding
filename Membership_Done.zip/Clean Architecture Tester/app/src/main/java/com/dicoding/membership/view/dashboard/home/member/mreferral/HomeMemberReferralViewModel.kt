package com.dicoding.membership.view.dashboard.home.member.mreferral

class HomeMemberReferralViewModel {
}