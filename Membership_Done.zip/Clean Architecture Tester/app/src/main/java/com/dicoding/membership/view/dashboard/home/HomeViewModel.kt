package com.dicoding.membership.view.dashboard.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.dicoding.core.domain.story.tester.usecase.StoryUseCaseTester
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val storyUseCase: StoryUseCaseTester
) : ViewModel() {

    fun getFavoriteStories() = storyUseCase.getFavoriteStories().asLiveData()
}