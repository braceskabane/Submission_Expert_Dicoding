package com.dicoding.membership.view.dashboard.history.poin

class HistoryTransferPointViewModel {
}