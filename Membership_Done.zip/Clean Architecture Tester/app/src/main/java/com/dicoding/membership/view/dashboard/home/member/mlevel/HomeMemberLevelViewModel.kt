package com.dicoding.membership.view.dashboard.home.member.mlevel

class HomeMemberLevelViewModel {
}