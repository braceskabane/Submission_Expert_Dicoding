package com.dicoding.membership.view.dashboard.home.member.mstatus

class HomeMemberStatusViewModel {
}