package com.dicoding.membership.view.dashboard.home.member.mregister

class HomeMemberRegisterViewModel {
}