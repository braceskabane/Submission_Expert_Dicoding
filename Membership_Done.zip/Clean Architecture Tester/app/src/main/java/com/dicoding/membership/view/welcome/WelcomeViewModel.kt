package com.dicoding.membership.view.welcome

class WelcomeViewModel {
}