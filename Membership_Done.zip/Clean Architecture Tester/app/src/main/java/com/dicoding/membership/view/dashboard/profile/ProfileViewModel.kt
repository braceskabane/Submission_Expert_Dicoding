package com.dicoding.membership.view.dashboard.profile

class ProfileViewModel {
}