package com.dicoding.favorite.view.history.test

import android.content.Context
import com.dicoding.membership.di.FavoriteModuleDependencies
import dagger.BindsInstance
import dagger.Component

@Component(dependencies = [FavoriteModuleDependencies::class])
interface StoryComponent {

    fun inject(activity: DetailStoryActivity)

    @Component.Builder
    interface Builder {
        fun context(@BindsInstance context: Context): Builder
        fun appDependencies(favoriteModuleDependencies: FavoriteModuleDependencies): Builder
        fun build(): StoryComponent
    }

}